<?php

include"header.php";
include"left.php";
include"right.php";


echo "<h1>Bagaimana Cara Memesan ?</h1> <br>";
echo "<li>Cek jenis produk yang ingin anda pesan.</li>";
echo "<li>Cek harga sudah sesuai ataukah belum.</li>";
echo "<li>Pilih Checkout barang.</li>";
echo "<li>Isi form pemesanan atau chat Admin di nomor 085778119750.</li>";
echo "<li>Lalu klik kirim.</li> <br>";

echo "<h1>Bagaimana Apabila Ada Kendala dalam Pemesanan ?</h1> <br>";
echo "Hubungi Penjual di Contact yang tertera atau kirimkan pesan ke SundaneseFood@gmail.com. <br><br>";

echo "<h1>Daerah Mana Saja yang Mencakup Wilayah Pemasaran ?</h1> <br>";
echo "<li>Griya Sekitarnya.</li>";
echo "<li>Klapaunggal Sekitarnya.</li>";
echo "<li>Wanaherang Sekitarnya.</li>";
echo "<li>Cikuda Sekitarnya.</li>";
echo "<li>Nambo Sekitarnya.</li> <br>";

echo "<h1>Apakah Produk Ini Terjamin ?</h1> <br>";
echo "Pastinya, karena bahan-bahan yang digunakan aman dan berkualitas. <br><br>";

echo'<div class="cleared"></div>';
include"footer.php";
?>
